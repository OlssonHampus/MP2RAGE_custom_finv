function figureJ(varargin);
if nargin==0
    gcf=figure;
else
gcf=figure(varargin{1});
end;
set(gcf,'Color',[1 1 1]);


